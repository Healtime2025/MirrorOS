# Mirror OS Command Center
This is the base frontend shell for the Mirror OS dashboard.

## Files
- `index.html` — Entry point
- `style.css` — Styling
- `app.js` — Logic placeholder

Ready for future API and dashboard integration.
